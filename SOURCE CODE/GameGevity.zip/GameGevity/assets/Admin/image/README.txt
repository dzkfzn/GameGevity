A Pen created at CodePen.io. You can find this one at https://codepen.io/jasonhibbs/pen/vnkaz.

 Concept for a better image uploader. Drag and drop, or file input, with preview.

Doesn’t cover all the angles yet.