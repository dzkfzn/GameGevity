<div class="cart_item">

    <div class="cart_item_price_container">


        <div class="cart_item_price ">
            <div class="price">Rp 219 999</div>
            <a class="remove_link" href="javascript:removeFromCart('2469564313958545161')">Remove</a>
        </div>
    </div>

    <div class="cart_item_img "><a href="https://store.steampowered.com/app/578080?snr=1_8_4__501"><img src="https://steamcdn-a.akamaihd.net/steam/apps/578080/capsule_sm_120.jpg?t=1545084399" border="0"></a></div>
    <div class="cart_item_desc">
        <div class="cart_item_platform">
            <span class="platform_img win"></span>								
        </div>
        <a href="https://store.steampowered.com/app/578080?snr=1_8_4__501">PLAYERUNKNOWN'S BATTLEGROUNDS</a>
        <br>
        <span class="cart_item_desc_ext">You already own this game<sup>1</sup></span>
        <br>
    </div>
    <div style="clear: left"></div>
</div>