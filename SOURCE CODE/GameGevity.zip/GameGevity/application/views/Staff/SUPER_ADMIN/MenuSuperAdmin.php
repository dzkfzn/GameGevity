<li>
    <a title="Dashboard" href="<?php echo base_url() ?>Dashboard/super_admin"><i class="fa fa-dashboard sub-icon-mg" aria-hidden="true"></i> <span class="mini-click-non">Dashboard</span></a>
</li>
<li >
    <a class="has-arrow" href="index.html">
        <i class="fa big-icon fa-home icon-wrap"></i>
        <span class="mini-click-non">Manage Master</span>
    </a>
    <ul class="submenu-angle" aria-expanded="true">

        <li><a title="Staff" href="<?php echo base_url() ?>Staff"><i class="fa fa-male sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Staff</span></a></li>     
        <li><a title="Staff" href="<?php echo base_url() ?>Role"><i class="fa fa-recycle sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Role</span></a></li>     

    </ul>
</li>
<li>
    <a class="has-arrow" href="index.html">
        <i class="fa big-icon fa-gear icon-wrap"></i>
        <span class="mini-click-non">Setting</span>
    </a>
    <ul class="submenu-angle" aria-expanded="true">

        <li><a title="Games" href="<?php echo base_url() ?>Password"><i class="fa fa-lock sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Change Password</span></a></li>
        <li><a title="Games" href="<?php echo base_url() ?>Change_Identity/getdata"><i class="fa fa-edit sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Change Identity</span></a></li>
    </ul>
</li>

<li>
    <a title="Logout" href="<?php echo base_url() ?>login/logout"><i class="fa fa-key sub-icon-mg" aria-hidden="true"></i> <span class="mini-click-non">Logout</span></a>
</li>