<li>
    <a title="Dashboard" href="<?php echo base_url() ?>Dashboard/manager"><i class="fa fa-dashboard sub-icon-mg" aria-hidden="true"></i> <span class="mini-click-non">Dashboard</span></a>
</li>
<li >
    <a class="has-arrow" href="index.html">
        <i class="fa big-icon fa-home icon-wrap"></i>
        <span class="mini-click-non">Report</span>
    </a>
    <ul class="submenu-angle" aria-expanded="true">

        <li><a title="Staff" href="<?php echo base_url() ?>dashboard/manager_profit"><i class="fa fa-male sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Profit</span></a></li>     
        <li><a title="Staff" href="<?php echo base_url() ?>Role"><i class="fa fa-recycle sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Games</span></a></li>     

    </ul>
</li>


<li>
    <a title="Logout" href="<?php echo base_url() ?>login/logout"><i class="fa fa-key sub-icon-mg" aria-hidden="true"></i> <span class="mini-click-non">Logout</span></a>
</li>