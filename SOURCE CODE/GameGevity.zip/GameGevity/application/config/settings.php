<?php

/* Google App Client Id */
define('CLIENT_ID', '348984212294-2r54goe1t29onr0bbbrgo6tgqcolrcfm.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'rVVDifTI5IRTCRqVy9K9OnFz');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://localhost:10/PRG5/PROJECT/GameGevity/index.php/Login_user');

?>