<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']="480061210784-vtikld7btq04f8r9v9aecjtkp00juq66.apps.googleusercontent.com";
$config['google_client_secret']="zO16KGEckQn828lIO6FzFCXp";
$config['google_redirect_url']=base_url().'auth/oauth2callback';

